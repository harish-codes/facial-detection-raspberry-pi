var searchData=
[
  ['loadfiles',['loadFiles',['../classDialog.html#a83609ca200829f8f22e0a602f260566b',1,'Dialog']]]
];
