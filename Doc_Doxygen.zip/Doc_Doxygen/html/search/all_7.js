var searchData=
[
  ['readdb',['ReadDB',['../classMainWindow.html#acad55ad7923f76a00cdc66a8dcc9bb0f',1,'MainWindow']]]
];
