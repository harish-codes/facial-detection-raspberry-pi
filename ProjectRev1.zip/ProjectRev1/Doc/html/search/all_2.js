var searchData=
[
  ['from',['FROM',['../dialog_8h.html#aa2af4e50ef1ce6ff75660ac127e61823',1,'dialog.h']]]
];
