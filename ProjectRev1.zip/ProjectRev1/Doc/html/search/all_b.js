var searchData=
[
  ['_7edialog',['~Dialog',['../classDialog.html#a2a1fe6ef28513eed13bfcd3a4da83ccb',1,'Dialog']]],
  ['_7emainwindow',['~MainWindow',['../classMainWindow.html#ae98d00a93bc118200eeef9f9bba1dba7',1,'MainWindow']]]
];
