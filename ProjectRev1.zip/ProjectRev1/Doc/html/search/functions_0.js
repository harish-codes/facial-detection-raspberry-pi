var searchData=
[
  ['detectanddraw',['detectAndDraw',['../classDialog.html#a4f27c706ea566225fe26d945dab43f2d',1,'Dialog']]],
  ['dialog',['Dialog',['../classDialog.html#ab30ac48588a82983f653f58d50a52ddc',1,'Dialog']]]
];
