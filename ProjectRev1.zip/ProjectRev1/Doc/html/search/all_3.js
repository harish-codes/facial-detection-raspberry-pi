var searchData=
[
  ['initdb',['InitDB',['../classMainWindow.html#a193e5789f1a9cbb37644308099e4fc8f',1,'MainWindow']]]
];
