var searchData=
[
  ['cc',['CC',['../dialog_8h.html#a78d126676907aa89a0adbfbef8282585',1,'dialog.h']]]
];
